
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">

<div class="main-menu-content">
    
<ul class="nav navbar-nav flex-row">
<li class="nav-item mr-auto">
                    <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>"><span
                            class="brand-logo">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" style="margin: 4px 3px 8px 20px;width: 45px;">
                    </a>
                </li>
                <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse">
                    <i class="d-block d-xl-none text-primary  font-medium-4" data-feather="menu" class="mr-1"></i>
                    <i class="d-none d-xl-block font-medium-4  text-primary" data-feather="menu" class="mr-1"></i>
                </a></li>

</ul>

            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class="<?php echo e(Request::segment(1) === 'dashboard' ? 'active' : ' '); ?>"><a class="d-flex align-items-center" href="<?php echo e(route('dashboard')); ?>">
                    <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Dashboard</span></a>
                    
                </li>              
                       
                <!-- <li class=" navigation-header"><span data-i18n="account"></span><i
                    data-feather="more-horizontal"></i>
                </li> -->

<?php if(count(array_intersect(['edit-project','create-project'], Auth::user()->getAllPermissions()->pluck('name')->toArray())) > 0): ?>

                <li class=""><a class="d-flex align-items-center" href="#">
                <i data-feather="clipboard"></i><span class="menu-title text-truncate"
          data-i18n="User">Projects</span></a>
         <ul class="menu-content range">
        <li><a class="" href="<?php echo e(route('projects.view_all')); ?>">
        <i data-feather="circle"></i><span
                class="menu-item text-truncate" data-i18n="List">View All</span></a>
        </li>
       <li><a class="d-flex align-items-center" href="<?php echo e(route('projects.create_new')); ?>"><i data-feather="circle"></i><span
                class="menu-item text-truncate" data-i18n="Preview">Create New</span></a>
       </li>
       <li><a class="d-flex align-items-center" href="<?php echo e(route('projects.update')); ?>"><i data-feather="circle"></i><span
                class="menu-item text-truncate" data-i18n="Edit">Update</span></a>
        </li>
            </ul>
            <?php endif; ?>

            <li class="<?php echo e(Request::segment(1) === 'roles' ? 'active' : (Request::segment(1) === 'permission' ? 'active' : ' ')); ?>"><a class="d-flex align-items-center" href="#">
            <i data-feather="package"></i><span class="menu-title text-truncate"
                        data-i18n="Role">Role Management</span></a>
                <ul class="menu-content">
                <li><a class="<?php echo e(Request::segment(1) === 'permission' ? 'active' : ' '); ?>" href="<?php echo e(route('permission.index')); ?>"><i data-feather="lock"></i><span
                                class="menu-item text-truncate" data-i18n="List">Permissions</span></a>
                    </li>
                    <li><a class="<?php echo e(Request::segment(1) === 'roles' ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>"><i data-feather="users"></i><span
                                class="menu-item text-truncate" data-i18n="List">Role</span></a>
                    </li>

                    
                    <!-- <li><a class="d-flex align-items-center" href="#"><i data-feather="circle"></i><span
                                class="menu-item text-truncate" data-i18n="List">Reports</span></a>
                    </li> -->
                    <!-- <li><a class="d-flex align-items-center" href="#"><i data-feather="circle"></i><span
                                class="menu-item text-truncate" data-i18n="Preview">Create New</span></a>
                    </li> -->
                    <!-- <li><a class="d-flex align-items-center" href=""><i data-feather="circle"></i><span
                                class="menu-item text-truncate" data-i18n="Edit">Update</span></a>
                    </li> -->

                </ul>
            </li>
            <li class="<?php echo e(Request::segment(1) === 'index' ? 'active' : (Request::segment(1) === 'usermanagement' ? 'active' : ' ')); ?>"><a class="d-flex align-items-center" href="#">
                <i data-feather="user"></i><span class="menu-title text-truncate"
        data-i18n="User">User Management</span></a>
<ul class="menu-content">
    <li><a class="<?php echo e(Request::segment(1) === 'useredit' ? 'active' : (Request::segment(1) === 'usermanagement' ? 'active' : ' ')); ?>" href="<?php echo e(route('usermanagement.index')); ?>"><i data-feather="users"></i><span
                class="menu-item text-truncate" data-i18n="List">User List</span></a>
    </li>
    <!-- <li><a class="d-flex align-items-center" href="#"><i data-feather="circle"></i><span
                class="menu-item text-truncate" data-i18n="Preview">Create New</span></a>
    </li> -->
    <!-- <li><a class="d-flex align-items-center" href=""><i data-feather="circle"></i><span
                class="menu-item text-truncate" data-i18n="Edit">Update</span></a>
    </li> -->

</ul>
</li>

        </div>

        </div>
    </div> <?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>