
   

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('roles.index')); ?>"  class="btn btn-primary btn-sm" 
                            ><i aria-hidden="true" class="fa fa-arrow-left"></i> Back
                     </a><br><br>
<div class="card">
                    <div class="card-header p-1">
                                    <h4 class="card-title"><b>Role List</b></h4>
                                    <div class="d-flex align-items-center">
                                    <p class="card-text mr-25 mb-0">
                                   
                                        </p>
                                    </div>
                                </div>                        
                    </div>   

   <div class="tab p-0">
  
            <div class="row mt-3 mb-3">
            <div class="col-lg-12 col-md-12">

           


            <div class="table-responsive">
                     <table class="table">
                        <thead>
                           <tr>
                              
                              <th>Role Name</th>
                              <th>Permissions</th>
                              <th>Role Created Date</th>                  
                           </tr>
                        </thead>
                        <tbody>     
               
                          
                         <tr>
                              <td><?php echo e($roles->name); ?></td>
                              <td><?php echo e(implode(', ', $roles->permissions->pluck('name')->toArray())); ?></td>
                              <td><?php echo e(date('m-d-Y', strtotime($roles->created_at))); ?></td>
                           </tr>
                          
                        
            </tbody>
                     </table> 
                   </div> 

            </div>
            </div>            
              </div>    
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/role/show.blade.php ENDPATH**/ ?>