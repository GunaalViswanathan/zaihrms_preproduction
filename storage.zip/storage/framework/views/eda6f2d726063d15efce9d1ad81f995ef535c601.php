

<?php $__env->startSection('content'); ?>
<!-- Page Heading  Start-->


<?php if(Session::has('Success')): ?>
    <div class="alert alert-success">
        <?php echo e(Session::get('Success')); ?>

    </div>
<?php endif; ?>

<a href="<?php echo e(route('usermanagement.index')); ?>" class="btn btn-primary btn-sm" ><i aria-hidden="true" class="fa fa-arrow-left"></i> Back</a> 
<br><br>
<div class="pb-1">
	<div class="d-flex align-items-center">
		<h5 class="card-text mr-25 mb-0">
		   Create a New User
</h5>
    </div>
</div>                                           
       
<!-- Side-Nav -->
<div class="card">
                        <div class="card-body">
							<h6><strong>Basic Information</strong></h6>
	
	<form method="POST" action="<?php echo e(route('usermanagement.store')); ?>"  enctype="multipart/form-data" class="form-horizontal" autocomplete="on">
			   <?php echo csrf_field(); ?>        
        	
          <div class="form-group mb-1">            
            <div class="row">
            	
                <div class="col-md-6 mb-1">
                	<div class="form-group">
                    <label for="name" class="control-label"> First Name <small class="text-danger required">*</small></label> 
							<input name="name" type="text" id="name" class="form-control" value="<?php echo e(old('name')); ?>">
							<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 											
					</div>		
                </div>      
				
				<div class="col-md-6 mb-1">
                	<div class="form-group">
                    <label for="last_name" class="control-label">Last Name</label> 
							<input name="last_name" type="text" id="last_name" class="form-control" value="<?php echo e(old('last_name')); ?>">
							<?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 											
					</div>		
                </div>    
				
        
            	<div class="col-md-6 mb-1">
                	<div class="form-group">
					<label for="email" class="control-label">Email Address <small class="text-danger required">*</small></label> 
							<input name="email" type="email" id="email"  class="form-control" value="<?php echo e(old('email')); ?>">
							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 												
					</div>		
                </div>

				<div class="col-md-6 mb-1">
                	<div class="form-group">
					<label for="mobile_no" class="control-label">Phone Number <small class="text-danger required">*</small></label> 
							<input name="mobile_no" type="text" id="mobile-no"  class="form-control" min="0" value="<?php echo e(old('mobile_no')); ?>">
							<?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 												
					</div>		
                </div>

	
					<div class="col-md-6 mb-1">
						<div class="form-group">
							<label for="password" class="control-label">Password<small class="text-danger required">*</small></label> 
							<input name="password" type="password" id="password" class="form-control" min="0" value="<?php echo e(old('password')); ?>" >
							<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
						</div>
					</div>

					<div class="col-md-6 mb-1">
						<div class="form-group">
							<label for="" class="control-label">Re-enter Password<small class="text-danger required">*</small></label> 
							<input name="confirm_password" type="password" id="re-enter-password" class="form-control" min="0" value="" >
							<?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
						</div>
					</div>

					<div class="col-md-6 mb-1">
                    <div class="form-group">
                     	<label for="state">State<small class="text-danger required">*</small></label>
                        <select class="form-control" id="state" name="state">
							<option value="">Select State</option>
							
							 
							<?php $__empty_1 = true; $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<option value="<?php echo e($state->code); ?>" <?php if(old('state') == $state->code): echo 'selected'; endif; ?>><?php echo e($state->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<?php endif; ?>
						</select>
						<?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

				

				<div class="col-md-6 mb-1">
                    <div class="form-group">
                     	<label for="role">Select User's Role<small class="text-danger required">*</small></label>
                        <select class="form-control" id="role" name="role">
							<option value="">Select Role</option>
							<?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<option value="<?php echo e($role->name); ?>"  <?php if(old('role') == $state->name): echo 'selected'; endif; ?>><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<?php endif; ?>
						</select>
						<?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>


				<div class="col-md-6 mb-1">
                	<div class="form-group">
					<label for="profile_photo"  class="control-label">Profile Picture</label> 
							<input name="profile_photo" type="file" id="profile_photo" class="form-control">
							 <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							 <span class="text-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 													
					</div>		
					<small style="color:blue">Allowed File Formats: jpg, jpeg, png .</small>
					<small style="color:blue">Allowed size : below <b>2MB</b></small>
                </div>

		  <div class="col-md-12 d-flex justify-content-end">	
          <div class="form-group mb-3">
              
			  <a href="<?php echo e(route('usermanagement.index')); ?>" class="btn btn-danger" ></i> Cancel  </a> 
			  <span><input type="submit" class=" btn btn-primary" value="Create"></span>
          </div> 
          </div>

        </div>
      </div>
    </div>


  

   
      

						</div>
						
					</div>
				  </div>
               </form>
            </div>
         </div>
		 <!-- <script>
 $(function () {

$('#mobile-no').keydown(function (e) {
 var key = e.charCode || e.keyCode || 0;
 $text = $(this); 
 if (key !== 8 && key !== 9) {
	 if ($text.val().length === 3) {
		 $text.val($text.val() + '-');
	 }
	 if ($text.val().length === 7) {
		 $text.val($text.val() + '-');
	 }

 }

 return (key == 8 || key == 9 || key == 46 || (key >= 48 && key <= 57) || (key >= 96 && key <= 105));
})
});

</script> -->

<!-- Page Content End-->				  
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/usermanagement/create.blade.php ENDPATH**/ ?>