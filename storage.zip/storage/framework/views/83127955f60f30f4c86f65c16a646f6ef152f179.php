



<?php $__env->startSection('content'); ?>


<?php if(Session::has('Success')): ?>
    <div class="alert alert-success">
        <?php echo e(Session::get('Success')); ?>

    </div>
<?php endif; ?>

<a href="<?php echo e(route('permission.index')); ?>" class="btn btn-primary btn-sm" 
                            ><i aria-hidden="true" class="fa fa-arrow-left"></i> Back
                     </a><br><br>
                            <div class="card">
                    <div class="card-header p-1">
                                    <h4 class="card-title"><b>Permissions</b></h4>
                                    <div class="d-flex align-items-center">
                                    <p class="card-text mr-25 mb-0">
                                   
                                        </p>
                                    </div>
                                </div>                        
                    </div>         
                    

        



                <section class="app-user-edit">
                    <div class="card">
                        <div class="card-body">

                            <!-- Account Tab starts -->
                            <div class="tab-pane active" id="account" aria-labelledby="account-tab" role="tabpanel">
                                <!-- users edit account form start -->
                                <form class="form-validate" novalidate method="POST" action="<?php echo e(route('permission.store')); ?>">
                                <?php echo method_field('POST'); ?>   
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                        <!-- <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="fristname"> Label</label>
                                                <input type="text" class="form-control" 
                                                    value="<?php echo e(old('label')); ?>" name="label" id="label">

                                     <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							          <span class="text-danger"><?php echo e($message); ?></span>
							         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                            </div>
                                        </div> -->

                                        

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="name"> Permission Name<small class="text-danger required">*</small></label>
                                                <input type="text" class="form-control"
                                                    value="<?php echo e(old('name')); ?>" name="name" id="name">
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							          <span class="text-danger"><?php echo e($message); ?></span>
							         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                            </div>
                                        </div>


                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="label_name">Label Name<small class="text-danger required">*</small></label>
                                                <input type="text" class="form-control"
                                                    value="<?php echo e(old('label_name')); ?>" name="label_name" id="label_name">
                                                    <?php $__errorArgs = ['label_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							          <span class="text-danger"><?php echo e($message); ?></span>
							         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                            </div>
                                        </div>


                                            <div><button type="submit"
                                                    class="btn btn-primary mb-1 mb-sm-0 mr-0 mr-sm-1 waves-effect waves-float waves-light">Create
                                                    New Permission</button></div>
                                            <!-- <button type="reset" class="btn btn-outline-secondary waves-effect">Reset</button> -->
                                        </div>
                                    </div>
                                </form>
                                <!-- users edit account form ends -->
                            </div>
                            <!-- Account Tab ends -->




                        </div>
                    </div>
                </section>
                <!--  Create From  end -->

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/permission/create.blade.php ENDPATH**/ ?>