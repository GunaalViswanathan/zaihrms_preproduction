<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light">
        <p class="clearfix mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">Copyright &copy; 2022<a
                    class="ml-25" href="#" target="_blank">| Honor Contracting, LLC |</a><span
                    class="d-none d-sm-inline-block">, B-03 Remodeling and Repair #: 327574</span></span>
                    <!-- <span class="float-md-right d-none d-md-block"> B-03 Remodeling and Repair #: 327574</span> -->
                </p>
    </footer>
    <button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/charts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/datatables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/ui/ui-feather.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/file-uploaders/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/forms/form-file-uploader.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/core/app.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <!-- <script src="<?php echo e(asset('app-assets/js/scripts/pages/dashboard-analytics.js')); ?>"></script> -->
    <script src="<?php echo e(asset('app-assets/js/scripts/pages/app-invoice-list.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset('app-assets/js/scripts/pages/permissions.js')); ?>"></script> -->
    <!-- END: Page JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/forms/validation/jquery.validate.min.js')); ?>"></script>
    <script>
        $(window).on('load', function () {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        })

       
    $(document).ready(function(){
//pace-done vertical-layout navbar-floating footer-static vertical-menu-modern menu-expanded
   if ($( "body" ).hasClass('menu-collapsed')) {
	$( "body" ).removeClass( 'menu-collapsed');
       $( "body" ).addClass( 'menu-expanded');
}
});
    
    </script>
<?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/layouts/footer.blade.php ENDPATH**/ ?>