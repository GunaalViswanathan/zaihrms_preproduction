

<?php $__env->startSection('content'); ?>

<?php if(Session::has('Success')): ?>
    <div role="alert" aria-live="polite" aria-atomic="true" class="alert alert-success" data-v-3bcd05f2="">
        </h4> <div class="alert-body"><span><?php echo e(Session::get('Success')); ?></span></div>
    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div role="alert" aria-live="polite" aria-atomic="true" class="alert alert-danger" data-v-3bcd05f2="">
        </h4> <div class="alert-body"><span><?php echo e(Session::get('error')); ?></span></div>
    </div>
<?php endif; ?>

<style>

a#reset_button {
    padding-left: 1em;
    vertical-align: middle;
}

.search-container {align-items: center;}

.search-container button[type=submit] {
    padding: 8px;
    border: 1px solid #d8d6de;
    border-radius: 0px 4px 4px 0px;
}

input#search {
    border-radius: 4px 0px 0px 4px;
}
    </style>


<!-- users list start -->
<section class="app-user-list">
                    <!-- users filter start -->
                    <div class="card">
                    <div class="card-header p-1">
                                    <h4 class="card-title"><b>User Lists</b></h4>
                                    <div class="d-flex align-items-center">
                                   
                                <div class="col-md-12">

                                <div class="sbar relative">
                                    <form action="<?php echo e(route('usermanagement.index')); ?>" method="GET" name="search" >
                                        <?php echo csrf_field(); ?>
                                   <div class="d-flex search-container">
                                    <input  class="form-control"type="text" id="search" name="search" value="<?php echo e(request('search','')); ?>" placeholder="Name & Email"/>
                                   <button type="submit"><i class="fas fa-search"></i></button>
                                    <a href="<?php echo e(route('usermanagement.index')); ?>" title="Reset" id="reset_button"  class="fas fa-undo"></a>
                    </div>   
                                </div>
                                </div>
                                </form>
                               </div>
                        <div class="col-md-3">

                    <form action="<?php echo e(route('usermanagement.index')); ?>" method="GET" name="role_filter" id="searchs" >
    
                    <select onchange="this.form.submit()" name="role" id="searchs" name="searchs" class="form-control" id="role" value="<?php echo e(request('searchs','')); ?>">
					<option value=""  selected="selected">All Roles </option>
					<?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<option  value="<?php echo e($role->id); ?>" <?php echo request('role') == $role->id ? ' selected' : ''; ?> ><?php echo e($role->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
					</select>
</form>

            </div>                            
                                  <p class="card-text mr-25 mb-0">
                                    <a href="<?php echo e(route('usermanagement.create')); ?>"  style="float:right;" title="Create" class="btn btn-primary btn-sm"><i aria-hidden="true" class="fa fa-plus"></i> Assign New User
                     </a>
                                        </p>
                                    </div>
                                </div>                        
                    </div>

                <div class="content-header row">
                    <div class="content-header-left col-md-9 col-12 mb-2">
                        <div class="row ">
                            <div class="col-12">
                                <h4 class="content-header-title float-left mb-0">View All User</h4>
                            </div>
                        </div>
                    </div>
                </div>

         

                <!--User View Start-->
                
                <section id="knowledge-base-content">
                    <div class="row kb-search-content-info match-height">
                    <?php $__empty_1 = true; $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-4 col-sm-6 col-12 kb-search-content user-img">
                            <div class="card text-center pt-3">
                                <a href="<?php echo e(route('usermanagement.show',$users->id)); ?>">
                                    <img src="<?php if($users->userProfile && $users->userProfile->profile_photo): ?> <?php echo e(asset('storage/upload/user/profile/'.$users->userProfile->profile_photo)); ?>

                     <?php else: ?> <?php echo e(asset('app-assets/images/avatars/7.png')); ?> <?php endif; ?>"  
                                    alt="" class="card-rounded" height="140" width="140">
                                    <div class="card-body text-center">
                                        <h4><?php echo e($users->name); ?> <?php echo e($users->last_name); ?></h4>
                                        <h5><?php echo e($users->roles && $users->roles->first() ? $users->roles->first()->name : ""); ?></h5>
                                        <p class="text-body mt-1 mb-0">
                                        <?php echo e($users->email); ?>

                                        </p>
                                        <p class="text-body mt-1 mb-0">
                                        (<?php echo e($users->getMobileNoAttribute()); ?>)
                                        </p>
                                        
                                    </div>
                                </a>
                                <!--dropdown menu start-->

                                <form  id="deleteForm" action="<?php echo e(route('usermanagement.delete',$users->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                <div class="dropdown">
                            <button class="btn-icon btn btn-flat-dark btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="more-vertical"></i></button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="<?php echo e(route('usermanagement.show',$users->id)); ?>"><i class="mr-1" data-feather="eye"></i><span class="align-middle">View</span></a>
                                <a class="dropdown-item" href="<?php echo e(route('usermanagement.edit',$users->id)); ?>"><i class="mr-1" data-feather="edit"></i><span class="align-middle">Edit</span></a>
                                <?php if(Auth::user()->id != $users->id): ?>
                                <button class="dropdown-item" data-toggle="modal" data-target="#small" type="button" 
                                        onclick="deleteModel(<?php echo e($users->id); ?>)">
                                    <i class="mr-1" data-feather="trash-2"></i><span class="align-middle">Delete</span>
                                </button>
                                <?php endif; ?>
                            </div>
                               </div>
                               </form>
                              <!--dropdown menu start-->
                              <div class="modal fade text-left" id="small" tabindex="-1" role="dialog" aria-labelledby="myModalLabel19" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel19">Delete</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <input type="hidden" id="users_id">
                                                        <div class="modal-body">
                                                          Are you sure you want to delete?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" onclick="triggerDelete()" id="delete-btn" class="btn btn-primary" data-dismiss="modal">Accept</button>
                                                            <button type="button" id="delete-btn" class="btn btn-danger" class="close" data-dismiss="modal" aria-label="Close">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          
                             <div class="col-md-6 text-right"> <h5> No User found!</h5> </div>
                           
                                   <?php endif; ?>
                    
         </div>
                    <?php echo $user->links('vendor.pagination.bootstrap-4'); ?>


                </section>
                <!--User View End-->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript">
   jQuery(document).ready(function(){
  var search = jQuery('#search').val();
  if (search.length > 0){
    jQuery("#reset_button").show();
  }
  else {
    jQuery("#reset_button").hide();
  }
});


var roleDelteURL="<?php echo e(route('usermanagement.delete',':id')); ?>"
     function deleteModel(id){ 
   jQuery('#users_id').val(id);
  }

  function triggerDelete(){
    var action_url = jQuery("#deleteForm").prop('action');
    let roleId=jQuery('#users_id').val();
   
    action_url=roleDelteURL.replace(':id',roleId);
    
    jQuery("#deleteForm").attr('action', action_url);
       
       jQuery("#deleteForm").submit();
  }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
<script type="text/javascript">
   jQuery(document).ready(function(){
  var search = jQuery('#searchs').val();
  if (search.length > 0){
    jQuery("#reset_button").show();
  }
  else {
    jQuery("#reset_button").hide();
  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/usermanagement/index.blade.php ENDPATH**/ ?>