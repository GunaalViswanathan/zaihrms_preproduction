

<?php $__env->startSection('content'); ?>

<?php if(Session::has('Success')): ?>
    <div role="alert" aria-live="polite" aria-atomic="true" class="alert alert-success" data-v-3bcd05f2="">
        </h4> <div class="alert-body"><span><?php echo e(Session::get('Success')); ?></span></div>
    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div role="alert" aria-live="polite" aria-atomic="true" class="alert alert-danger" data-v-3bcd05f2="">
        </h4> <div class="alert-body"><span><?php echo e(Session::get('error')); ?></span></div>
    </div>
<?php endif; ?>



<style>

a#reset_button {
    padding-left: 1em;
    vertical-align: middle;
}

.search-container {align-items: center;}

.search-container button[type=submit] {
    padding: 8px;
    border: 1px solid #d8d6de;
    border-radius: 0px 4px 4px 0px;
}

input#search {
    border-radius: 4px 0px 0px 4px;
}
    </style>

<!-- users list start -->
 <section class="app-user-list">
                    <!-- users filter start -->
                    <div class="card">
                    <div class="card-header p-1">
                                    <h4 class="card-title"><b>Role</b></h4>
                                   <div class="d-flex align-items-center ">
                            <div class="col-md-12">
                                <div class="sbar relative">
                                    <form action="<?php echo e(route('roles.index')); ?>" method="GET" name="search" >
                                   <div class="d-flex search-container">
                                    <input  class="form-control"type="text" id="search" name="search" value="<?php echo e(request('search','')); ?>" placeholder="Name"/>
                                   <button type="submit"><i class="fas fa-search"></i></button>
                                    <a href="<?php echo e(route('roles.index')); ?>" title="Reset" id="reset_button"  class="fas fa-undo"></a>
</div>   
                                </div>
                                </div>
                                   </form>
                               </div>
                                  
                                 
                             
                                    <div class="d-flex align-items-center">
                                    <p class="card-text mr-25 mb-0">
                                    <a href="<?php echo e(route('roles.create')); ?>" title="" class="btn btn-primary btn-sm" 
                            ><i aria-hidden="true" class="fa fa-plus"></i> Create Role
                     </a>
                                        </p>
                                    </div>
                                </div>                        
                    </div>                   
                    <!-- users filter end -->
                    <!-- list section start -->

                    <div class="card">
                        <div class="card-datatable table-responsive pt-0">
                            <table class="user-list-table table c-table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Permissions</th>                                   
                                        <th class="action-btn">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><p><?php echo e($role->name); ?></p></td>
                                        <td><p><?php echo e(implode(', ', $role->permissions->pluck('name')->toArray())); ?></p></td> 
                                        <td class="action-btn">
                                        <form  id="deleteForm" action="<?php echo e(route('roles.destroy',$role->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                         <a href="<?php echo e(route('roles.show', $role->id)); ?>" title="Show"
                                          class="btn  btn-info btn-sm" ><i aria-hidden="true" 
                                          class="fa fa-eye"></i>
                                         </a>

                                         <a href="<?php echo e(route('roles.edit', $role->id)); ?>" title="Edit"
                                          class="btn btn-primary btn-sm"><i aria-hidden="true" 
                                          class="fa fa-edit"></i>
                                         </a> 

                                         <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#small" type="button" 
                                         onclick="deleteModel(<?php echo e($role->id); ?>)" title="Delete" >
                                        <i aria-hidden="true" class="fa fa-trash"></i>
                                            </button>
                                         </td>
                                         </form>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                              <td class="text-center" colspan="12">No Role found!</td>
                           </tr>
                                    <?php endif; ?>
                                   
                                </tbody>
                            </table>

                            <div class="modal-size-sm d-inline-block">
                                            <!-- Button trigger modal -->
                                         
                                            <!-- Modal -->
                                            <div class="modal fade text-left" id="small" tabindex="-1" role="dialog" aria-labelledby="myModalLabel19" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel19">Delete</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <input type="hidden" id="role_id">
                                                        <div class="modal-body">
                                                          Are you sure you want to delete?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" onclick="triggerDelete()" id="delete-btn" class="btn btn-primary" data-dismiss="modal">Accept</button>
                                                            <button type="button" id="delete-btn" class="btn btn-danger" class="close" data-dismiss="modal" aria-label="Close">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                        </div>
                        <!-- Modal to add new user starts-->
                     
                        <!-- Modal to add new user Ends-->
                    </div>

                    
                    <?php echo $roles->links('vendor.pagination.bootstrap-4'); ?>

                    <!-- list section end -->
                </section>

                     
                <?php $__env->stopSection(); ?>
                <?php $__env->startSection('script'); ?>
              

<script type="text/javascript">
   jQuery(document).ready(function(){
  var search = jQuery('#search').val();
  console.log("Search", search);
  if (search.length > 0){
    jQuery("#reset_button").show();
  }
  else {
    jQuery("#reset_button").hide();
  }
});

                        
     var roleDelteURL="<?php echo e(route('roles.destroy',':id')); ?>"


  function deleteModel(id){
   $('#role_id').val(id);
   
  }

  function triggerDelete(){
    var action_url = $("#deleteForm").prop('action');
    let roleId=$('#role_id').val();
    action_url=roleDelteURL.replace(':id',roleId);
    //alert(action_url);
        $("#deleteForm").attr('action', action_url);
       // alert(action_url);
        $("#deleteForm").submit();
    

  }
</script>
                <!-- users list ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/role/index.blade.php ENDPATH**/ ?>