
   

<?php $__env->startSection('content'); ?>


<a href="<?php echo e(route('usermanagement.index')); ?>" class="btn btn-primary btn-sm" ><i aria-hidden="true" class="fa fa-arrow-left"></i> Back</a> 
<br><br>

<div class="col-xl-12 col-lg-12 col-md-12 p-0">
                            <div class="card user-card min-height-4">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-xl-5 col-lg-12 d-flex flex-column justify-content-between border-container-lg">
                                            <div class="user-avatar-section">
                                                <div class="d-flex justify-content-start">
                                                    <img class="img-fluid rounded" src="<?php if($users->userProfile && $users->userProfile->profile_photo): ?> <?php echo e(asset('storage/upload/user/profile/'.$users->userProfile->profile_photo)); ?> <?php else: ?> <?php echo e(asset('app-assets/images/avatars/7.png')); ?> <?php endif; ?>" height="170" width="170" alt="User avatar" />
                                                    <div class="d-flex flex-column ml-1">
                                                        <div class="user-info mb-1">
                                                            <h4 class="mb-0"><?php echo e($users->name); ?> <?php echo e($users->last_name); ?></h4>
                                                            <span class="card-text"><?php echo e($users->email); ?></span>
                                                        </div>
                                                        <div class="d-flex flex-wrap">
                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- <div class="d-flex align-items-center user-total-numbers">
                                                <div class="d-flex align-items-center mr-2">
                                                    <div class="color-box bg-light-primary">
                                                        <i data-feather="dollar-sign" class="text-primary"></i>
                                                    </div>
                                                    <div class="ml-1">
                                                        <h5 class="mb-0">23.3k</h5>
                                                        <small>Monthly Sales</small>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center">
                                                    <div class="color-box bg-light-success">
                                                        <i data-feather="trending-up" class="text-success"></i>
                                                    </div>
                                                    <div class="ml-1">
                                                        <h5 class="mb-0">$99.87K</h5>
                                                        <small>Annual Profit</small>
                                                    </div>
                                                </div>
                                            </div> -->
                                        </div>
                                        <div class="col-xl-7 col-lg-12 mt-2 mt-xl-0">
                                            <div class="user-info-wrapper">
                                                <div class="d-flex flex-wrap">
                                                    <div class="user-info-title">
                                                        <i data-feather="user" class="mr-1"></i>
                                                        <span class="card-text user-info-title font-weight-bold mb-0">Username : </span>
                                                    </div>
                                                    <?php echo "&nbsp;"; ?>

                                                    <p class="card-text mb-0">  <?php echo e($users->name); ?> <?php echo e($users->last_name); ?> </p>
                                                </div>
                                                <div class="d-flex flex-wrap my-50">
                                                    <div class="user-info-title">
                                                        <i data-feather="mail" class="mr-1"></i>
                                                        <span class="card-text user-info-title font-weight-bold mb-0">Email : </span>
                                                    </div>
                                                    <?php echo "&nbsp;"; ?>

                                                    <p class="card-text mb-0">  <?php echo e($users->email); ?></p>
                                                </div>

                                                <?php if($users->userProfile): ?>
                                             
                                                <div class="d-flex flex-wrap my-50">
                                                    <div class="user-info-title">
                                                        <i data-feather="map-pin" class="mr-1"></i>
                                                        <span class="card-text user-info-title font-weight-bold mb-0">State : </span>
                                                    </div>
                                                    <?php echo "&nbsp;"; ?>

                                                    <p class="card-text mb-0">  <?php echo e($users->userProfile->state); ?></p>
                                                </div>
                                              

                                                <div class="d-flex flex-wrap my-50">
                                                    <div class="user-info-title">
                                                        <i data-feather="phone" class="mr-1"></i>
                                                        <span class="card-text user-info-title font-weight-bold mb-0">Phone Number : </span>
                                                    </div>
                                                    <?php echo "&nbsp;"; ?>

                                                    <p class="card-text mb-0">  (<?php echo e($users->getMobileNoAttribute()); ?>)</p>
                                                </div>
                                               
                                                <div class="d-flex flex-wrap my-50">
                                                    <div class="user-info-title">
                                                        <i data-feather="users" class="mr-1"></i>
                                                        <span class="card-text user-info-title font-weight-bold mb-0"> Role : </span>
                                                    </div>
                                                    <?php echo "&nbsp;"; ?>

                                                    <p class="card-text mb-0">  <?php echo e($users->roles->first()->name); ?></p>
                                                </div>
                                                <?php else: ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/usermanagement/show.blade.php ENDPATH**/ ?>