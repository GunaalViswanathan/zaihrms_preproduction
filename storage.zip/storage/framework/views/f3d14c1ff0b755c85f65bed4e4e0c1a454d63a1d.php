

<?php $__env->startSection('content'); ?>

<div class="card mb-0">
                            <div class="card-body">
                                <a href="javascript:void(0);" class="brand-logo">
                                    
                          <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo">
                                </a>

                                <h4 class="card-title mb-1 text-center">Login to your account</h4>
                              
                                <form class="auth-login-form mt-2" action="<?php echo e(route('validateLogin')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                <div class="form-group">
                                        <label for="login-email" class="form-label">Email</label>
                                        <input type="text" class="form-control" id="login-email" name="email" placeholder="Enter Your Username" aria-describedby="login-email" tabindex="1" autofocus />
                                    </div>

                                    <div class="form-group">
                                      
                                        <div class="input-group input-group-merge form-password-toggle">
                                            <input type="password" class="form-control form-control-merge" id="login-password" name="password" tabindex="2" placeholder="Enter Your Password" aria-describedby="login-password" />
                                            <div class="input-group-append">
                                                <span class="input-group-text cursor-pointer"><i data-feather="eye"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="form-group">
                                      <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" type="checkbox" id="remember-me" tabindex="3" />
                                            <label class="custom-control-label" for="remember-me"> Remember Me </label>
                                        </div> 
                                    </div> -->
                                    <button class="btn btn-primary btn-block" tabindex="4">Log In</button>
                                </form>

                                <div class="text-center mt-5">
                                  <a href="forgot-password.html">
                                        <small>Forgot Password?</small>
                                    </a>
                                </div>

                                <p class="text-center">
                                    <span>Don't have an account?</span>
                                    <a href="#">
                                        <span>Register</span>
                                    </a>
                                </p>

                                                            
                            </div>
                        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('outerpages.layout_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/login.blade.php ENDPATH**/ ?>