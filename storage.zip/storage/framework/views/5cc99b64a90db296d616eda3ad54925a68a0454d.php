

<?php $__env->startSection('content'); ?>


         <div class="card mb-0 br-15">
                <div class="card-body login-form">
                     <a href="javascript:void(0);" class="brand-logo">        
                        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo">
                     </a>
                    <h4 class="card-title mb-1 text-center">Login to your account</h4>
                    <form class="auth-login-form mt-2" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">                                        
                                        <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="login-email" name="email" placeholder="Enter Your Username" value="<?php echo e(old('email')); ?>" aria-describedby="login-email" tabindex="1" autofocus />
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>                        
                        <div class="form-group">                        
                             <div class="input-group input-group-merge form-password-toggle">                                        
                                         <input type="password" class="form-control form-control-merge  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="login-password" name="password" tabindex="2" placeholder="Enter Your Password" aria-describedby="login-password"  />
                                            <div class="input-group-append">
                                                <span class="input-group-text cursor-pointer"><i data-feather="eye"></i></span>
                                            </div>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             </div>     
                        </div>     
                       
                      

                        <div class="row mb-1">
                               <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Login')); ?>

                                </button>
                                </div>                       
                            </div>
                                <p class="text-center mb-0">
                                <i class="fas fa-lock"></i>
                                <?php if(Route::has('password.request')): ?>                                
                                <a href="<?php echo e(route('password.request')); ?>">
                                      <small>Forgot Password?</small>
                                  </a>                          
                                <?php endif; ?>
                                </p>
                                <p class="text-center">
                                <small><span>Don't have an account?</span>
                                    <a href="<?php echo e(route('register')); ?>" style="text-decoration:underline;">
                                        <span>Register</span>
                                    </a>
                                   </small>
                                </p>
                                 
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('outerpages.layout_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\honor-contracting\resources\views/auth/login.blade.php ENDPATH**/ ?>